#ifndef __POWER_SERVER
#define __POWER_SERVER

void setupServerModule();

#endif