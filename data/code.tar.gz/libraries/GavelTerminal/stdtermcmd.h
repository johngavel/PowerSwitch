#ifndef __GAVEL_STANDARD_TERMINAL_COMMDANDS
#define __GAVEL_STANDARD_TERMINAL_COMMDANDS

void addStandardTerminalCommands();

#endif