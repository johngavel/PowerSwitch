#ifndef __GAVEL_ARCH
#define __GAVEL_ARCH

#include "gpio.h"
#include "scan.h"
#include "serialport.h"
#include "startup.h"
#include "taskmanager.h"
#include "watchdog.h"

#endif
